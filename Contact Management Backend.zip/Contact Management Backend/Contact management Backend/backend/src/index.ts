import 'dotenv/config';
import express, { Request, Response, NextFunction, Application, urlencoded, json } from 'express';
import * as path from 'path';
import * as fs from 'fs';
import cors from 'cors';
import chalk from 'chalk';
import mongoose from 'mongoose';
import helmet from 'helmet';
import winston from 'winston';
import compression from 'compression';
import morgan from 'morgan';
import { WriteStream } from 'fs';
import nocache from 'nocache';
import rateLimit from './middlewares/rateLimit';
import Logger from './utils/winston.utils';
import Routes from './routes/v1/route-index';
import Status from './utils/status-codes-messages.utils';

// ✅ Ensure logs folder exists in the build directory
const logsDir = path.join(__dirname, 'logs');
if (!fs.existsSync(logsDir)) {
  fs.mkdirSync(logsDir, { recursive: true });
}

export default class App {
  private serverPort: number = process.env.PORT ? parseInt(process.env.PORT, 10) : 3000;
  public app: Application = express();
  private accessLogStream: WriteStream = fs.createWriteStream(path.join(__dirname, './logs/access.log'), { flags: 'a' });

  constructor() {
    // Middleware: body parser
    this.app.use(json());
    this.app.use(urlencoded({ extended: false }));

    // Middleware: logging
    this.app.use(morgan('dev'));
    this.app.use(morgan('combined', { stream: this.accessLogStream }));

    // Middleware: security and performance
    this.app.use(
      cors({
        origin: ['http://localhost:3000', 'https://kontact-five.vercel.app', '*'],
        credentials: true,
      })
    );
    this.app.use(rateLimit());
    this.app.use(compression());
    this.app.use(nocache());
    this.app.use(helmet());

    // Middleware: XSS protection
    this.app.use((req: Request, res: Response, next: NextFunction) => {
      res.setHeader('X-XSS-Protection', '1; mode=block');
      next();
    });

    // Load routes
    new Routes(this.app);
  }

  // Clear the console
  private _clearConsole(): void {
    process.stdout.write('\x1B[2J\x1B[0f');
  }

  // App entry point
  public async bootstrap() {
    this._clearConsole();
    const uri: string = process.env.MONGODB_URI;

    mongoose.set('strictQuery', false);

    mongoose.connect(uri).then(() => {
      Logger.info('MongoDB Connect: ' + Status.DB_LOGS.DB_CONNECTED_SYNC_SUCCESS_MSG);
      console.log(chalk.green.bold('Server successfully connected with MongoDB!'));

      this.app
        .listen(this.serverPort, () => {
          const msg = `Server running on : http://localhost:${process.env.PORT}`;
          console.info(msg);
          Logger.info(msg);
        })
        .on('error', (err: Error) => {
          console.error(err);
        });
    });

    // Catch unexpected shutdown errors
    process.on('beforeExit', (err) => {
      winston.error(JSON.stringify(err));
      console.error(err);
    });
  }
}
