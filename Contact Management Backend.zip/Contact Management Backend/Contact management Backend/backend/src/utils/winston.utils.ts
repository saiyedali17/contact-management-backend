import { createLogger, format, transports } from 'winston';
import appRoot from 'app-root-path';
import * as fs from 'fs';

const { combine, timestamp, label, printf } = format;

// Make sure logs folder exists
const logDir = `${appRoot}/src/logs`;
if (!fs.existsSync(logDir)) {
  fs.mkdirSync(logDir, { recursive: true });
}

// Custom log message format
const myFormat = printf(({ level, message, label, timestamp }: any) => {
  return `${timestamp} [${label}] [${level.toUpperCase()}]: ${message}`;
});

// Logger options
const options = {
  globalLogs: {
    level: 'info',
    filename: `${logDir}/global.log`,
    handleExceptions: true,
    json: true,
    maxsize: 5 * 1024 * 1024, // 5MB
    maxFiles: 100,
    colorize: false,
  },
  redirectionLogs: {
    level: 'info',
    filename: `${logDir}/api-redirection.log`,
    handleExceptions: true,
    json: true,
    maxsize: 5 * 1024 * 1024,
    maxFiles: 100,
    colorize: false,
  },
  errorFile: {
    level: 'error',
    filename: `${logDir}/error.log`,
    handleExceptions: true,
    json: true,
    maxsize: 5 * 1024 * 1024,
    maxFiles: 100,
    colorize: false,
  },
  console: {
    level: 'debug',
    handleExceptions: true,
    json: false,
    colorize: true,
  },
};

// Final logger setup
const Logger = createLogger({
  format: combine(label({ label: 'Kontact' }), timestamp(), myFormat),
  transports: [
    new transports.File(options.errorFile),
    new transports.File(options.globalLogs),
    new transports.File(options.redirectionLogs),
    new transports.Console(options.console), // ✅ Logs to terminal
  ],
  exitOnError: false,
});

export default Logger;
